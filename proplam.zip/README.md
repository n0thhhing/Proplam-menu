
## Introduction
This repository contains an open-source Game Guardian menu for the game "PIXEL-GUN-3D".

just save all the files, put them in the same folder, make sure the names are the same as the repo, then just run proplam.lua