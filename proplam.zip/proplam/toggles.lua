ON = '[🟢]'
OFF = '[🔴]'
--config
emulator = false
--defult values--
coval = tbi --collectibles
cvalue = '2b'
lotval = tbi --lottery collectibles
value = '2b'
selr = myt --rarity
raree = 'Mythical'
colorr = '🟣'
--account--
le = OFF
lb = OFF
ce = OFF
cp = OFF
ie = OFF
--armory--
pm = OFF
ug = OFF
uh = OFF
uc = OFF
fc = OFF
ur = OFF
ah = OFF
su = OFF
uw = OFF
ua = OFF
sd = OFF
uu = OFF
pa = OFF
xm = OFF
mp = OFF
ra = OFF
rart = 1
--rewards--
co = OFF
lo = OFF
zz = OFF
ff = OFF
fl = OFF
fa = OFF
sp = OFF
uc = OFF
eg = OFF
pp = OFF
ma = OFF
rp = OFF
eh = OFF
ga = OFF
cracked = OFF
crack = false
--clickers--
task = OFF
pass = OFF
gemc = OFF
bmcl = OFF
--gameplay--
inf = OFF
fir = OFF
rel = OFF
gcd = OFF
tem = OFF
swe = OFF
god = OFF
tgod = OFF
petr = OFF
rewp = OFF
xrewm = OFF
xrewm = OFF
asc = OFF
zomb = OFF
checkc = OFF
